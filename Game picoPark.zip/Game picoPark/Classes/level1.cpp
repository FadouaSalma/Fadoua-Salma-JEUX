#include "level1.h"
#include "level2.h"
#include "ui/UITextField.h"
#include "AudioEngine.h"

USING_NS_CC;

Scene* Lvl1::createScene()
{
    auto scene = Scene::createWithPhysics();
     scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
    scene->getPhysicsWorld()->setGravity(Vec2(0,-400));
    //scene->getPhysicsWorld()->setDebugDrawMask(0xffff);
    auto layer = Lvl1::create();
    scene->addChild(layer);
    return scene;
}

// Print useful error message instead of segfaulting when files are not there

// on "init" you need to initialize your instance
bool Lvl1::init()
{
    if (!Layer::init())
    {
        return false;
    }

    //------------------------------------------------------------create backgroud color-------------------------------------------------

    LayerColor* _bgColor = LayerColor::create(Color4B::WHITE);
    this->addChild(_bgColor, -10);

    //---------------------------------------------create variables for positioning our instance-------------------------------------------------------

    auto visibleSize = Director::getInstance()->getWinSize();
    
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    //-------------------------------------------------create an edge box for our game------------------------------------------------------

    auto edgebody = PhysicsBody::createEdgeBox(visibleSize, PHYSICSBODY_MATERIAL_DEFAULT, 3);
    edgebody->setCollisionBitmask(3);
    edgebody->setContactTestBitmask(true);
    auto edgeNode = Node::create();
    edgeNode->setPosition(Point((visibleSize.width / 2) , (visibleSize.height / 2)));
    edgeNode->setPhysicsBody(edgebody);
    this->addChild(edgeNode);
    
    
    ground = Sprite::create("ground.png");
    ground->setScale(2.05);
    auto Frame4body = PhysicsBody::createBox(Size(ground->getContentSize().width, ground->getContentSize().height), PhysicsMaterial(0, 0, 0));
    Frame4body->setCollisionBitmask(2);
    Frame4body->setContactTestBitmask(true);
    ground->setPosition(Point(origin.x + 200, origin.y + 15));
    if (Frame4body != nullptr)
    {
        Frame4body->setDynamic(false);
        ground->setPhysicsBody(Frame4body);
    }
    this->addChild(ground);

    auto gound2 = Sprite::create("ground.png");
    gound2->setScale(2.05);
    auto gound2body = PhysicsBody::createBox(Size(gound2->getContentSize().width, gound2->getContentSize().height), PhysicsMaterial(0, 0, 0));
    gound2body->setCollisionBitmask(2);
    gound2body->setContactTestBitmask(true);
    gound2->setPosition(Point(origin.x + 925, origin.y + 15));
    if (gound2body != nullptr)
    {
        gound2body->setDynamic(false);
        gound2->setPhysicsBody(gound2body);
    }
    this->addChild(gound2);



    player = new OurPlayer(this);
    player->setposition(origin.x + 200, origin.y + 90);
    key = new OurKey(this);
    key->setposition(visibleSize.width - 100, origin.y +80);
    door = new OurDoor(this);
    door->setposition(origin.x +100, origin.y + 85);
    door->setposition2(origin.x + 100, origin.y + 85);
    lights = new OurLight(this);

    this->setScale(1.3);
    auto camera = Camera::create();
    camera->setPositionZ(5);
    camera->clearBackground();
    this->addChild(camera);
    this->scheduleUpdate();
;
        this->schedule(SEL_SCHEDULE(&Lvl1::signal), 3.9);
        this->schedule(SEL_SCHEDULE(&Lvl1::switchLights), 4);
    
       
    bridge = new OurBridge(this);
   
  
   
   
    

    auto eventListener = EventListenerKeyboard::create();

    eventListener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event* event) {
     
            switch (keyCode) {
                //case wich key is pressed
            case EventKeyboard::KeyCode::KEY_LEFT_ARROW: 
            case EventKeyboard::KeyCode::KEY_A:
              
                isLeftPressed = true;
                    this->schedule(SEL_SCHEDULE(&Lvl1::moveleft), 0.01);
                
                break;
            case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
            case EventKeyboard::KeyCode::KEY_D:
              
                isRightPressed = true;
                    this->schedule(SEL_SCHEDULE(&Lvl1::moveright), 0.01);
                 
                break;
            case EventKeyboard::KeyCode::KEY_SPACE:
            case EventKeyboard::KeyCode::KEY_W:
                if (isSpacePressed == false)
                {
                    this->schedule(SEL_SCHEDULE(&Lvl1::movetop), 0.01);
                    isSpacePressed = true;
                    isPlayerOnGround = false;
                    cocos2d::AudioEngine::preload("audio/jump.mp3");
                    cocos2d::AudioEngine::play2d("audio/jump.mp3", false, 0.3f);
                }
                
                   
                    
            
                break;
            case EventKeyboard::KeyCode::KEY_UP_ARROW:

                isUpPressed = true;

                break;
                  
            } 

      
           

    };
    eventListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event)
    {
   
            switch (keyCode) {
                //case wich key is pressed
            case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
            case EventKeyboard::KeyCode::KEY_A:
              
                isLeftPressed = false;
                    this->unschedule(SEL_SCHEDULE(&Lvl1::moveleft));
                 
                break;
            case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
            case EventKeyboard::KeyCode::KEY_D:
              
                isRightPressed = false;
                    this->unschedule(SEL_SCHEDULE(&Lvl1::moveright));
                   
                break;
            case EventKeyboard::KeyCode::KEY_SPACE:
            case EventKeyboard::KeyCode::KEY_W:

                    this->unschedule(SEL_SCHEDULE(&Lvl1::movetop));
                        log("landed");
                  
                 
                   
                break;
          
            case EventKeyboard::KeyCode::KEY_UP_ARROW:

                isUpPressed = false;

                break;
         
            }
    };
    

    this->_eventDispatcher->addEventListenerWithSceneGraphPriority(eventListener, this);

    auto contactListener = EventListenerPhysicsContact::create();

    contactListener->onContactBegin = CC_CALLBACK_1(Lvl1::onContactBegin, this);
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(contactListener, this);
    return true;
}
void Lvl1::moveright(float dt) {
    Vec2 playerPos = player->getposition();
    player->setposition(playerPos.x + 80* dt, playerPos.y);
}
void Lvl1::moveleft(float dt) {
    Vec2 ballpos = player->getposition();
    player->setposition(ballpos.x - 80 * dt, ballpos.y);
}

void Lvl1::movetop(float dt) {
    Vec2 ballpos = player->getposition();
    player->setposition(ballpos.x, ballpos.y + 160 * dt);
}
void Lvl1::switchLights(float dt) {
    isLightGreen = !isLightGreen;
    if (isLightGreen)
    {
        log("go");
        lights->greenLight();
    }
    else
    {
        log("stop");
        lights->redLight();
    }
}
void Lvl1::signal(float dt) {
    cocos2d::AudioEngine::preload("audio/lightChange.mp3");
    cocos2d::AudioEngine::play2d("audio/lightChange.mp3", false, 0.3f);
}


bool Lvl1::onContactBegin(cocos2d::PhysicsContact& contact)
{
    PhysicsBody* a = contact.getShapeA()->getBody();
    PhysicsBody* b = contact.getShapeB()->getBody();
    auto p = contact.getContactData()->points;

    // check if the bodies have collided
    if ((1 == a->getCollisionBitmask() && 2 == b->getCollisionBitmask()) || (2 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        isSpacePressed = false;
        if (!isPlayerOnGround)
        {
            cocos2d::AudioEngine::preload("audio/land.mp3");
            cocos2d::AudioEngine::play2d("audio/land.mp3", false, 0.3f);
        }
    }
    else if ((1 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())) {
        isDoorOpened = false;
        auto scene = Lvl1::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.2, scene));
    }
    else if ((4 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 4 == b->getCollisionBitmask())) {
        bridge->removeFromParent1();
    }
    else if ((5 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 5 == b->getCollisionBitmask())) {
        bridge->removeFromParent2();
    }
    else if ((6 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 6 == b->getCollisionBitmask())) {
        bridge->removeFromParent3();
    }
    else if ((7 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 7 == b->getCollisionBitmask())) {
        bridge->removeFromParent4();
    }

    else if ((1 == a->getCollisionBitmask() && 4 == b->getCollisionBitmask()) || (4 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        this->schedule(SEL_SCHEDULE(&Lvl1::fallfirstbridge), 0.5);
        isSpacePressed = false;
    }
    else if ((1 == a->getCollisionBitmask() && 5 == b->getCollisionBitmask()) || (5 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        isSpacePressed = false;
        this->schedule(SEL_SCHEDULE(&Lvl1::fallsecondbridge), 0.5);
    }
    else if ((1 == a->getCollisionBitmask() && 6 == b->getCollisionBitmask()) || (6== a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        isSpacePressed = false;
        this->schedule(SEL_SCHEDULE(&Lvl1::fallthirdbridge), 0.5);
    }
    else if ((1 == a->getCollisionBitmask() && 7 == b->getCollisionBitmask()) || (7 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        isSpacePressed = false;
        this->schedule(SEL_SCHEDULE(&Lvl1::fallfourthbridge), 0.5);
    }

    return true;
}
 

void Lvl1::fallfirstbridge(float dt ) {
  
    bridge->fall1();
}
void Lvl1::fallsecondbridge(float dt) {

    bridge->fall2();
}
void Lvl1::fallthirdbridge(float dt) {

    bridge->fall3();
}
void Lvl1::fallfourthbridge(float dt) {

    bridge->fall4();
}

void Lvl1::update(float dt) {
    if (!isLightGreen && isRightPressed)
    {
        auto scene = Lvl1::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.2, scene));
        isRightPressed = false;
        isLightGreen = false;
    }
    if (!isLightGreen && isLeftPressed)
    {
        auto scene = Lvl1::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.2, scene));
        isLeftPressed = false;
        isLightGreen = false;
    }


        Rect rect1 = player->getrect();
        Rect rect2 = key->getrect();
        Rect rect3 = door->getrect();
        Rect rect5 = ground->getBoundingBox();
        auto v = Director::getInstance()->getWinSize();
        Layer::setAnchorPoint(Vec2(player->getposition().x / v.width, player->getposition().y /v.height));
         
        if (rect1.intersectsRect(rect2))
        {
            key->setposition(player->getposition().x-10, player->getposition().y + 10);
            
            
        }
        if (rect2.intersectsRect(rect3) && isUpPressed == true && isDoorOpened == false) {
            key->removeFromParent();
            door->OpenDoor();
            //isDpressed = true;
            isDoorOpened = true;
            isUpPressed = false;
            
        }
        if (rect1.intersectsRect(rect3) && isDoorOpened == true && isUpPressed==true) {
            isUpPressed = false;
            auto scene = Lvl2::createScene();
            Director::getInstance()->replaceScene(TransitionFade::create(0.2, scene));
        }
        if (isLeftPressed)
        {
            player->turnLeft(180);
        }
        else if (isRightPressed)
        {
            player->turnRight();

        }


}