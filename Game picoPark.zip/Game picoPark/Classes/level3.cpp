#include "level3.h"
#include "menu.h"
#include "ui/UITextField.h"
#include "AudioEngine.h"

USING_NS_CC;

int jmpCount = 3;
int jmphight = 0;
Scene* Lvl3::createScene()
{
    auto scene = Scene::createWithPhysics();
    scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
    scene->getPhysicsWorld()->setGravity(Vec2(0, -400));
    //scene->getPhysicsWorld()->setDebugDrawMask(0xffff);
    auto layer = Lvl3::create();
    scene->addChild(layer);
    return scene;
}

// Print useful error message instead of segfaulting when files are not there

// on "init" you need to initialize your instance
bool Lvl3::init()
{
    if (!Layer::init())
    {
        return false;
    }

    //------------------------------------------------------------create backgroud color-------------------------------------------------

    LayerColor* _bgColor = LayerColor::create(Color4B::WHITE);
    this->addChild(_bgColor, -10);

    //---------------------------------------------create variables for positioning our instance-------------------------------------------------------

    auto visibleSize = Director::getInstance()->getWinSize();
    
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    //-------------------------------------------------create an edge box for our game------------------------------------------------------

    auto edgebody = PhysicsBody::createEdgeBox(visibleSize, PHYSICSBODY_MATERIAL_DEFAULT, 3);
    edgebody->setCollisionBitmask(3);
    edgebody->setContactTestBitmask(true);
    auto edgeNode = Node::create();
    edgeNode->setPosition(Point((visibleSize.width / 2) , (visibleSize.height / 2)));
    edgeNode->setPhysicsBody(edgebody);
    this->addChild(edgeNode);
    
    this->setScale(1.3);
    ground = Sprite::create("ground.png");
    ground->setScale(2.2);
    auto Frame4body = PhysicsBody::createBox(Size(ground->getContentSize().width, ground->getContentSize().height), PhysicsMaterial(0, 0, 0));
    Frame4body->setCollisionBitmask(2);
    Frame4body->setContactTestBitmask(true);
    ground->setPosition(Point(origin.x + 200, origin.y + 15));
    if (Frame4body != nullptr)
    {
        Frame4body->setDynamic(false);
        ground->setPhysicsBody(Frame4body);
    }
    this->addChild(ground);

    auto gound2 = Sprite::create("ground.png");
    gound2->setScale(2.2);
    auto gound2body = PhysicsBody::createBox(Size(gound2->getContentSize().width, gound2->getContentSize().height), PhysicsMaterial(0, 0, 0));
    gound2body->setCollisionBitmask(2);
    gound2body->setContactTestBitmask(true);
    gound2->setPosition(Point(origin.x + 1000, origin.y + 15));
    if (gound2body != nullptr)
    {
        gound2body->setDynamic(false);
        gound2->setPhysicsBody(gound2body);
    }
    this->addChild(gound2);



    player = new OurPlayer(this);
    player->setposition(origin.x + 200, origin.y + 90);
    key = new OurKey(this);
    key->setposition(visibleSize.width - 100, origin.y +80);
    door = new OurDoor(this);
    door->setposition(origin.x +100, origin.y + 85);
    door->setposition2(origin.x + 100, origin.y + 85);
    auto camera = Camera::create();
    camera->setPositionZ(5);
    camera->clearBackground();
    this->addChild(camera);
    this->scheduleUpdate();
   
   
  
   
   
    

    auto eventListener = EventListenerKeyboard::create();

    eventListener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event* event) {
     
            switch (keyCode) {
                //case wich key is pressed
            case EventKeyboard::KeyCode::KEY_LEFT_ARROW: 
            case EventKeyboard::KeyCode::KEY_A:
              
                isLeftPressed = true;
                    this->schedule(SEL_SCHEDULE(&Lvl3::moveleft), 0.01);
                
                break;
            case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
            case EventKeyboard::KeyCode::KEY_D:
              
                isRightPressed = true;
                    this->schedule(SEL_SCHEDULE(&Lvl3::moveright), 0.01);
                 
                break;
            case EventKeyboard::KeyCode::KEY_SPACE:
            case EventKeyboard::KeyCode::KEY_W:
                if (isSpacePressed == false && jmpCount > 0)
                {
                    this->schedule(SEL_SCHEDULE(&Lvl3::movetop), 0.01);
                    jmpCount -= 1;
                    jmphight += 1;
                    log("%d" , jmphight);
                   
                    isPlayerOnGround = false;
                    cocos2d::AudioEngine::preload("audio/jump.mp3");
                    cocos2d::AudioEngine::play2d("audio/jump.mp3", false, 0.3f);
                    if (jmpCount<=0)
                    {
                        isSpacePressed = true;
                    }
                }
                
                   
                    
            
                break;
            case EventKeyboard::KeyCode::KEY_UP_ARROW:

                isUpPressed = true;

                break;
                  
            } 

      
           

    };
    eventListener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event* event)
    {
   
            switch (keyCode) {
                //case wich key is pressed
            case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
            case EventKeyboard::KeyCode::KEY_A:
              
                isLeftPressed = false;
                    this->unschedule(SEL_SCHEDULE(&Lvl3::moveleft));

                 
                break;
            case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
            case EventKeyboard::KeyCode::KEY_D:
              
                isRightPressed = false;
                    this->unschedule(SEL_SCHEDULE(&Lvl3::moveright));

                  
                break;
            case EventKeyboard::KeyCode::KEY_SPACE:
            case EventKeyboard::KeyCode::KEY_W:
                    this->unschedule(SEL_SCHEDULE(&Lvl3::movetop));
                   
                        log("landed");
                  
                 
                   
                break;
            case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
            case EventKeyboard::KeyCode::KEY_S:
             
                    this->unschedule(SEL_SCHEDULE(&Lvl3::movebot));
                   
                break;
            case EventKeyboard::KeyCode::KEY_UP_ARROW:

                isUpPressed = false;

                break;
         
            }
    };
    
    timeTxt0 = Label::createWithTTF("tab3k", "fonts/Marker Felt.ttf", 25);
    timeTxt0->setTextColor(Color4B::BLACK);
   
    this->addChild(timeTxt0);
    this->_eventDispatcher->addEventListenerWithSceneGraphPriority(eventListener, this);
    //we create a contact listener to detect the collision of the ball with te walls and the obstacles
    auto contactListener = EventListenerPhysicsContact::create();
    //make a call back to the function everytime a contact happen
    contactListener->onContactBegin = CC_CALLBACK_1(Lvl3::onContactBegin, this);
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(contactListener, this);
    return true;
}
void Lvl3::moveright(float dt) {
    Vec2 playerPos = player->getposition();
    player->setposition(playerPos.x + 80* dt, playerPos.y);
}
void Lvl3::moveleft(float dt) {
    Vec2 ballpos = player->getposition();
    player->setposition(ballpos.x - 80 * dt, ballpos.y);
}
void Lvl3::movebot(float dt) {
    Vec2 ballpos = player->getposition();
    player->setposition(ballpos.x, ballpos.y -80 * dt);
}
void Lvl3::movetop(float dt) {
    Vec2 ballpos = player->getposition();
    player->setposition(ballpos.x, ballpos.y + 160*jmphight* dt);
}

bool Lvl3::onContactBegin(cocos2d::PhysicsContact& contact)
{
    PhysicsBody* a = contact.getShapeA()->getBody();
    PhysicsBody* b = contact.getShapeB()->getBody();
    auto p = contact.getContactData()->points;

    // check if the bodies have collided
    if ((1 == a->getCollisionBitmask() && 2 == b->getCollisionBitmask()) || (2 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask()))
    {
        isSpacePressed = false;
        jmpCount = 3;
        jmphight = 0;
        if (!isPlayerOnGround)
        {
            cocos2d::AudioEngine::preload("audio/land.mp3");
            cocos2d::AudioEngine::play2d("audio/land.mp3", false, 0.3f);
        }
    }
    else if ((1 == a->getCollisionBitmask() && 3 == b->getCollisionBitmask()) || (3 == a->getCollisionBitmask() && 1 == b->getCollisionBitmask())) {
        isDoorOpened = false;
        auto scene = Lvl3::createScene();
        Director::getInstance()->replaceScene(TransitionFade::create(0.2, scene));
    }
    return true;
}
 

void Lvl3::update(float dt) {

        timeTxt0->setPosition(Vec2(player->getposition().x, player->getposition().y + 65));
        std::string mytime = std::to_string(jmpCount);
        timeTxt0->setString(mytime);

        Rect rect1 = player->getrect();
        Rect rect2 = key->getrect();
        Rect rect3 = door->getrect();
        Rect rect5 = ground->getBoundingBox();
        auto v = Director::getInstance()->getWinSize();
        Layer::setAnchorPoint(Vec2(player->getposition().x / v.width, player->getposition().y /v.height));
         
        if (rect1.intersectsRect(rect2))
        {
            key->setposition(player->getposition().x-10, player->getposition().y + 10);
            
            
        }
        if (rect2.intersectsRect(rect3) && isUpPressed == true && isDoorOpened == false) {
            key->removeFromParent();
            door->OpenDoor();
            //isDpressed = true;
            isDoorOpened = true;
            isUpPressed = false;
            
        }
        if (rect1.intersectsRect(rect3) && isDoorOpened == true && isUpPressed==true) {
            isUpPressed = false;
            auto scene = MainMenu::createScene();
            Director::getInstance()->replaceScene(TransitionFade::create(0.8, scene));
        }
        if (isLeftPressed)
        {
            player->turnLeft(180);
        }
        else if (isRightPressed)
        {
            player->turnRight();

        }

        //condition to moove to next level 

}