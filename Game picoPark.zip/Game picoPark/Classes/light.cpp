#include "light.h"

USING_NS_CC;

OurLight::OurLight(cocos2d::Layer* layer) {
	visibleSize = Director::getInstance()->getVisibleSize();
	auto s = Director::getInstance()->getWinSize();
	origin = Director::getInstance()->getVisibleOrigin();
	green = Sprite::create("green.png");
	green->setScale(0.15);
	green->setPosition(Point(origin.x+550, origin.y + 350));
	red = Sprite::create("red.png");
	red->setScale(0.035);
	red->setPosition(Point(origin.x + 550, origin.y+350));
	green->setVisible(false);

	layer->addChild(green, 0);
	layer->addChild(red, 0);
};

cocos2d::Vec2 OurLight::getposition() {
	return green->getPosition();
}

void  OurLight::setposition(float x, float y) {
	green->setPosition(Point(x, y));
}

void  OurLight::setposition2(float x, float y) {
	red->setPosition(Point(x, y));
}
void OurLight::redLight() {
	green->setVisible(false);
	red->setVisible(true);
	exist = false;
}
void OurLight::greenLight() {
	green->setVisible(true);
	red->setVisible(false);
	exist = false;
}

