
#ifndef __BUTTON_H__
#define __BUTTON_H__

#include "cocos2d.h"
using namespace cocos2d;
//creating a class representing every image in the layer in other word every square in the layer surface and walls
class OurBridge
{

public:

	cocos2d::Vec2 getposition();
	void setposition(float x, float y);
	cocos2d::Rect getrect();
	void removeFromParent1();
	void removeFromParent2();
	void removeFromParent3();
	void removeFromParent4();
	void fall1();
	void fall2();
	void fall3();
	void fall4();
	OurBridge(cocos2d::Layer* layer);
private:
	cocos2d::Size visibleSize;
	cocos2d::Vec2 origin;
	//desctructor
	//this is where we initiate the sprite with a file path,
	cocos2d::Sprite* button1;
	cocos2d::Sprite* button2;
	cocos2d::Sprite* button3;
	cocos2d::Sprite* button4;
	

};
#endif