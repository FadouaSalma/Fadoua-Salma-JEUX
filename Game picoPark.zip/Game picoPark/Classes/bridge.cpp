#include "bridge.h"

USING_NS_CC;

OurBridge::OurBridge(cocos2d::Layer* layer) {
	visibleSize = Director::getInstance()->getVisibleSize();
	origin = Director::getInstance()->getVisibleOrigin();
	button1 = Sprite::create("box.png");
	button1->setScale(1.2);
	button1->setPosition(Point(origin.x + 510, origin.y + 35));
	auto width = button1->getContentSize().width;
	auto  b1 = PhysicsBody::createBox(button1->getContentSize(), PhysicsMaterial(0, 0, 0));
	b1->setCollisionBitmask(4);
	b1->setContactTestBitmask(true);
	b1->setDynamic(false);
	auto  b2 = PhysicsBody::createBox(button1->getContentSize(), PhysicsMaterial(0, 0, 0));
	b2->setCollisionBitmask(5);
	b2->setContactTestBitmask(true);
	b2->setDynamic(false);
	auto  b3 = PhysicsBody::createBox(button1->getContentSize(), PhysicsMaterial(0, 0, 0));
	b3->setCollisionBitmask(6);
	b3->setContactTestBitmask(true);
	b3->setDynamic(false);
	auto  b6 = PhysicsBody::createBox(button1->getContentSize(), PhysicsMaterial(0, 0, 0));
	b6->setCollisionBitmask(7);
	b6->setContactTestBitmask(true);
	b6->setDynamic(false);


	button1->setPhysicsBody(b1);
	button2 = Sprite::create("box.png");
	button2->setScale(1.2);
	button2->setPosition(Point(origin.x + 545, origin.y + 35));
	button2->setPhysicsBody(b2);
	
	button3 = Sprite::create("box.png");
	button3->setScale(1.2);
	button3->setPosition(Point(origin.x + 580, origin.y + 35));
	button3->setPhysicsBody(b3);
	
	button4 = Sprite::create("box.png");
	button4->setScale(1.2);
	button4->setPosition(Point(origin.x + 615 , origin.y + 35));
	button4->setPhysicsBody(b6);
	

	layer->addChild(button1, 1);
	layer->addChild(button2, 1);
	layer->addChild(button3, 1);
	layer->addChild(button4, 1);

};

cocos2d::Vec2 OurBridge::getposition() {
	return button1->getPosition();
}

void  OurBridge::setposition(float x, float y) {
	button1->setPosition(Point(x, y));
}
void OurBridge::fall1() {
	button1 ->getPhysicsBody()->setDynamic(true);
}
void OurBridge::fall2() {
	button2->getPhysicsBody()->setDynamic(true);
}

void OurBridge::fall3() {
	button3->getPhysicsBody()->setDynamic(true);
}

void OurBridge::fall4() {
	button4->getPhysicsBody()->setDynamic(true);
}
void OurBridge::removeFromParent1() {
	button1->getPhysicsBody()->removeFromWorld();
	button1->setVisible(false);
}
void OurBridge::removeFromParent2() {
	button2->getPhysicsBody()->removeFromWorld();
	button2->setVisible(false);
}
void OurBridge::removeFromParent3() {
	button3->getPhysicsBody()->removeFromWorld();
	button3->setVisible(false);
}
void OurBridge::removeFromParent4() {
	button4->getPhysicsBody()->removeFromWorld();
	button4->setVisible(false);
}


cocos2d::Rect OurBridge::getrect() {
	return button1->getBoundingBox();
}
